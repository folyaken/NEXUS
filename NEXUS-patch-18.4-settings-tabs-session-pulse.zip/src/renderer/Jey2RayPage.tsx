import { useEffect, useMemo, useRef, useState } from 'react';
import type { AppSettings, UpdateInfo, VpnProfile, VpnRuntime, VpnSubscriptionInfo } from '../main/types';
import { canConnect, displayName } from '../main/vpn-classify';
import { Flag } from './Flag';
import { ConnectionDiagnostics } from './ConnectionDiagnostics';
import { SubscriptionManager, type SubscriptionAction } from './SubscriptionManager';

function cleanError(error: unknown): string {
  const raw = error instanceof Error ? error.message : String(error);
  return raw.replace(/^Error invoking remote method '[^']+':\s*(?:Error:\s*)?/i, '').trim();
}

const EMPTY_RUNTIME: VpnRuntime = {
  status: 'disconnected',
  activeProfileId: null,
  activeName: null,
  connectedAt: null,
  pid: null,
  inboundPort: 10808,
  xrayReady: false,
  xrayVersion: null,
  subscriptions: [],
};

function subscriptionKey(profile: VpnProfile): string {
  return profile.subscriptionUrl || 'manual';
}

function sameSubscription(left?: string, right?: string): boolean {
  if (!left || !right) return false;
  try {
    const first = new URL(left.trim());
    const second = new URL(right.trim());
    first.hash = '';
    second.hash = '';
    return first.toString() === second.toString();
  } catch {
    return left.trim() === right.trim();
  }
}

function formatBytes(value?: number): string {
  if (!value) return '0 MB';
  const mb = value / (1024 * 1024);
  if (mb < 1024) return `${mb < 10 ? mb.toFixed(1) : Math.round(mb)} MB`;
  return `${(mb / 1024).toFixed(1)} GB`;
}

function formatWhen(value?: string): string {
  if (!value) return '—';
  return new Intl.DateTimeFormat('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }).format(new Date(value));
}

function formatSessionDuration(connectedAt: string | null, now: number): string {
  const started = connectedAt ? Date.parse(connectedAt) : Number.NaN;
  const elapsedSeconds = Number.isFinite(started) ? Math.max(0, Math.floor((now - started) / 1000)) : 0;
  const hours = Math.floor(elapsedSeconds / 3600);
  const minutes = Math.floor((elapsedSeconds % 3600) / 60);
  const seconds = elapsedSeconds % 60;
  return [hours, minutes, seconds].map((value) => String(value).padStart(2, '0')).join(':');
}

function formatExpire(value?: string): string {
  if (!value) return 'без срока';
  const date = new Date(value);
  const days = Math.round((date.getTime() - Date.now()) / 86_400_000);
  const stamp = new Intl.DateTimeFormat('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric' }).format(date);
  if (days < 0) return `${stamp} · истекла`;
  if (days === 0) return `${stamp} · сегодня`;
  return `${stamp} · ещё ${days} дн.`;
}

function stackOf(profile: VpnProfile): string {
  return profile.stack || `${profile.protocol.toUpperCase()} / ${(profile.params.network || 'TCP').toUpperCase()} / ${(profile.params.security || 'NONE').toUpperCase()} / JSON`;
}

function telegramOf(info?: VpnSubscriptionInfo): string | null {
  const blob = `${info?.title || ''} ${info?.supportUrl || ''} ${info?.announce || ''}`;
  const match = blob.match(/@[\w_]{4,}/);
  if (match) return match[0];
  try {
    if (info?.supportUrl && /t\.me\//i.test(info.supportUrl)) return `@${new URL(info.supportUrl).pathname.replace(/^\//, '')}`;
  } catch { /* ignore */ }
  return info?.title || null;
}

function latencyScore(profile: VpnProfile): number {
  if (typeof profile.pingMs === 'number' && profile.pingMs >= 0) return profile.pingMs;
  if (profile.pingMs === -1) return 8_000;
  return 40_000;
}

function pickFastest(list: VpnProfile[]): VpnProfile | null {
  const ready = list.filter((item) => !canConnect(item));
  if (!ready.length) return null;
  return [...ready].sort((a, b) => latencyScore(a) - latencyScore(b))[0];
}

function Signal({ ms }: { ms?: number | null }) {
  if (ms == null) {
    return <span className="happ-ping off" title="Ещё не измеряли"><span className="happ-signal off">{[1, 2, 3, 4].map((bar) => <i key={bar} />)}</span><em>—</em></span>;
  }
  if (ms < 0) {
    return <span className="happ-ping soft" title="Порт не отвечает на TCP, но узел рабочий (часто Reality / Hysteria)">
      <span className="happ-signal soft">{[1, 2, 3, 4].map((bar) => <i key={bar} className={bar <= 3 ? 'on' : ''} />)}</span>
      <em>ок</em>
    </span>;
  }
  const level = ms < 60 ? 4 : ms < 120 ? 3 : ms < 220 ? 2 : 1;
  const tone = level >= 3 ? 'good' : level === 2 ? 'ok' : 'weak';
  return <span className={`happ-ping ${tone}`} title={`${ms} мс`}>
    <span className={`happ-signal ${tone}`}>{[1, 2, 3, 4].map((bar) => <i key={bar} className={bar <= level ? 'on' : ''} />)}</span>
    <em>{ms}</em>
  </span>;
}

function profileLocation(profile: VpnProfile | null): { country: string; detail: string } {
  if (!profile) return { country: 'Сервер не выбран', detail: 'Выбери сервер слева' };
  const shownName = displayName(profile).trim();
  const knownCountry = profile.countryName?.trim();
  const country = knownCountry && knownCountry !== 'Другие' ? knownCountry : shownName;
  const city = profile.city?.trim();
  if (city) return { country, detail: `${country} · ${city}` };
  const parts = shownName.split(/\s*[·•|]\s*/).filter(Boolean);
  if (parts.length > 1 && parts[0].toLocaleLowerCase('ru-RU') === country.toLocaleLowerCase('ru-RU')) {
    return { country, detail: `${country} · ${parts.slice(1).join(' · ')}` };
  }
  return { country, detail: country };
}

export function Jey2RayPage({
  settings,
  updates,
  syncing,
  onSync,
  onSettings,
  onToast,
}: {
  settings: AppSettings;
  updates: UpdateInfo[];
  syncing: boolean;
  onSync: () => void;
  onSettings: (next: AppSettings) => void;
  onToast: (message: string) => void;
}) {
  const [link, setLink] = useState('');
  const [name, setName] = useState('');
  const [importOpen, setImportOpen] = useState(false);
  const [subscriptionsOpen, setSubscriptionsOpen] = useState(false);
  const [diagnosticsOpen, setDiagnosticsOpen] = useState(false);
  const [profiles, setProfiles] = useState<VpnProfile[]>([]);
  const [runtime, setRuntime] = useState<VpnRuntime>(EMPTY_RUNTIME);
  const [busy, setBusy] = useState(false);
  const [action, setAction] = useState<'refresh' | 'ping' | null>(null);
  const [subscriptionAction, setSubscriptionAction] = useState<SubscriptionAction | null>(null);
  const [tab, setTab] = useState('all');
  const [selectedId, setSelectedId] = useState<string | null>(settings.lastVpnProfileId);
  const [latencyMs, setLatencyMs] = useState<number | null>(null);
  const [modeSwitching, setModeSwitching] = useState<'proxy' | 'tun' | null>(null);
  const [sessionNow, setSessionNow] = useState(Date.now());
  const autoPing = useRef(false);
  const desktop = Boolean(window.nexus);
  const xrayUpdate = updates.find((item) => item.id === 'jey2ray');
  const mode = settings.vpnMode === 'tun' ? 'tun' : 'proxy';
  const storedAppRouting = settings.vpnAppRouting === 'exclude' || settings.vpnAppRouting === 'include'
    ? settings.vpnAppRouting
    : settings.vpnSplitTunnel
      ? 'include'
      : 'system';

  useEffect(() => {
    const api = window.nexus;
    if (!api?.getVpn) return;
    void api.getVpn().then((snapshot) => {
      setProfiles(snapshot.profiles);
      setRuntime(snapshot.runtime);
      if (snapshot.runtime.activeProfileId) setSelectedId(snapshot.runtime.activeProfileId);
    }).catch((error: Error) => onToast(cleanError(error)));
    return api.onVpnChanged((snapshot) => {
      setProfiles(snapshot.profiles);
      setRuntime(snapshot.runtime);
    });
  }, [onToast]);

  useEffect(() => {
    if (!desktop || runtime.xrayReady) return;
    void window.nexus?.ensureVpnCore().then(() => window.nexus?.getVpn()).then((snapshot) => {
      if (snapshot) setRuntime(snapshot.runtime);
    }).catch((error: Error) => onToast(cleanError(error)));
  }, [desktop, runtime.xrayReady, onToast]);

  useEffect(() => {
    setSessionNow(Date.now());
    if (runtime.status !== 'connected' || !runtime.connectedAt) return;
    const timer = window.setInterval(() => setSessionNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, [runtime.status, runtime.connectedAt]);

  const nodes = useMemo(() => profiles.filter((item) => item.kind !== 'notice'), [profiles]);
  const tabs = useMemo(() => ['all', ...new Set(nodes.map(subscriptionKey))], [nodes]);
  const visible = useMemo(() => tab === 'all' ? nodes : nodes.filter((item) => subscriptionKey(item) === tab), [nodes, tab]);
  const fastest = useMemo(() => pickFastest(visible), [visible]);
  const listed = useMemo(
    () => fastest ? [fastest, ...visible.filter((item) => item.id !== fastest.id)] : visible,
    [fastest, visible],
  );
  const info: VpnSubscriptionInfo | undefined = tab !== 'all' && tab !== 'manual'
    ? (runtime.subscriptions ?? []).find((item) => item.url === tab)
    : undefined;
  const selected = nodes.find((item) => item.id === selectedId) ?? fastest ?? nodes.find((item) => !canConnect(item)) ?? nodes[0] ?? null;
  const activeProfile = nodes.find((item) => item.id === runtime.activeProfileId) ?? null;
  const onAir = runtime.status === 'connected' && runtime.activeProfileId === selected?.id;
  const otherLive = runtime.status === 'connected' && runtime.activeProfileId !== selected?.id;
  const panelProfile = runtime.status === 'connected' ? (activeProfile || selected) : selected;
  const panelLocation = profileLocation(panelProfile);
  const displayedMode = modeSwitching ?? mode;
  const sessionDuration = formatSessionDuration(runtime.connectedAt, sessionNow);
  const used = (info?.upload ?? 0) + (info?.download ?? 0);
  const quota = info?.total ? formatBytes(info.total) : '∞';
  const title = tab === 'all' ? 'Все серверы' : tab === 'manual' ? 'Ручные профили' : telegramOf(info) || 'Подписка';

  const importLink = async () => {
    try {
      setBusy(true);
      if (!desktop) {
        onToast('Импорт ссылок работает в окне Electron (npm start)');
        return;
      }
      const imported = await window.nexus?.importVpn(link, name || undefined);
      if (imported?.length) {
        setLink('');
        setImportOpen(false);
        if (imported[0].subscriptionUrl) setTab(imported[0].subscriptionUrl);
        setSelectedId(imported[0].id);
        onToast(`Подписка: серверов ${imported.length}`);
      }
    } catch (error) {
      onToast(cleanError(error) || 'Не удалось импортировать ссылку');
    } finally {
      setBusy(false);
    }
  };

  const selectConnectionMode = async (next: 'proxy' | 'tun') => {
    if (next === mode || modeSwitching) return;
    if (runtime.status === 'connecting' || busy) {
      onToast('Дождитесь завершения текущего подключения');
      return;
    }
    const nextSettings = {
      ...settings,
      vpnMode: next,
      vpnAppRouting: storedAppRouting,
      vpnSplitTunnel: next === 'tun' && storedAppRouting === 'include',
    };
    if (!desktop || runtime.status !== 'connected') {
      onSettings(nextSettings);
      return;
    }

    try {
      setBusy(true);
      setModeSwitching(next);
      await window.nexus?.switchVpnMode(next);
      onSettings(nextSettings);
      onToast(`Режим ${next.toUpperCase()} включён · VPN переподключён`);
    } catch (error) {
      const persisted = await window.nexus?.getSettings().catch(() => null);
      if (persisted) onSettings(persisted);
      onToast(cleanError(error) || 'Не удалось переключить режим VPN');
    } finally {
      setModeSwitching(null);
      setBusy(false);
    }
  };

  const connect = async (id: string) => {
    const profile = nodes.find((item) => item.id === id);
    const blocked = profile ? canConnect(profile) : 'Сервер не найден';
    if (blocked) {
      onToast(blocked);
      return;
    }
    try {
      setBusy(true);
      setSelectedId(id);
      if (!desktop) {
        setRuntime({ ...runtime, status: 'connected', activeProfileId: id, pid: 4400 });
        return;
      }
      await window.nexus?.connectVpn(id);
    } catch (error) {
      onToast(cleanError(error) || 'Не удалось подключиться');
    } finally {
      setBusy(false);
    }
  };

  const disconnect = async () => {
    try {
      setBusy(true);
      if (desktop) await window.nexus?.disconnectVpn();
      else setRuntime({ ...runtime, status: 'disconnected', activeProfileId: null, pid: null });
    } catch (error) {
      onToast(cleanError(error) || 'Не удалось отключить VPN');
    } finally {
      setBusy(false);
    }
  };

  const togglePower = async () => {
    if (!selected) {
      onToast('Сначала выбери сервер слева');
      return;
    }
    if (onAir) await disconnect();
    else await connect(selected.id);
  };

  const holdAction = async (kind: 'refresh' | 'ping', work: () => Promise<void>, minMs: number) => {
    setAction(kind);
    const started = Date.now();
    try {
      await work();
    } finally {
      const wait = minMs - (Date.now() - started);
      if (wait > 0) await new Promise((resolve) => setTimeout(resolve, wait));
      setAction(null);
    }
  };

  const refresh = () => holdAction('refresh', async () => {
    try {
      const count = await window.nexus?.refreshVpn();
      onToast(count ? `Обновлено · ${count}` : 'Нет подписок');
    } catch (error) {
      onToast(cleanError(error));
    }
  }, 1100);

  const addManagedSubscription = async (url: string): Promise<boolean> => {
    try {
      const parsed = new URL(url);
      if (parsed.protocol !== 'https:') {
        onToast('Подписка должна использовать только HTTPS');
        return false;
      }
      if (!desktop) {
        onToast('Добавление подписок работает в окне Electron (npm start)');
        return false;
      }
      setSubscriptionAction({ kind: 'add', url });
      const imported = await window.nexus?.importVpn(url);
      if (!imported?.length) return false;
      const subscriptionUrl = imported[0].subscriptionUrl || url;
      setTab(subscriptionUrl);
      setSelectedId(imported[0].id);
      onToast(`Подписка добавлена · серверов ${imported.length}`);
      return true;
    } catch (error) {
      onToast(cleanError(error) || 'Не удалось добавить подписку');
      return false;
    } finally {
      setSubscriptionAction(null);
    }
  };

  const refreshManagedSubscription = async (url: string): Promise<void> => {
    try {
      setSubscriptionAction({ kind: 'refresh', url });
      const count = await window.nexus?.refreshVpn(url);
      onToast(`Подписка обновлена · серверов ${count ?? 0}`);
    } catch (error) {
      onToast(cleanError(error) || 'Не удалось обновить подписку');
    } finally {
      setSubscriptionAction(null);
    }
  };

  const refreshManagedSubscriptions = async (): Promise<void> => {
    try {
      setSubscriptionAction({ kind: 'refresh-all' });
      const count = await window.nexus?.refreshVpn();
      onToast(count ? `Все подписки обновлены · серверов ${count}` : 'Нет подписок');
    } catch (error) {
      onToast(cleanError(error) || 'Не удалось обновить подписки');
    } finally {
      setSubscriptionAction(null);
    }
  };

  const removeManagedSubscription = async (url: string): Promise<boolean> => {
    try {
      setSubscriptionAction({ kind: 'remove', url });
      await window.nexus?.removeVpnSubscription(url);
      if (sameSubscription(tab, url)) setTab('all');
      const selectedProfile = profiles.find((profile) => profile.id === selectedId);
      if (sameSubscription(selectedProfile?.subscriptionUrl, url)) setSelectedId(null);
      onToast('Подписка и её серверы удалены');
      return true;
    } catch (error) {
      onToast(cleanError(error) || 'Не удалось удалить подписку');
      return false;
    } finally {
      setSubscriptionAction(null);
    }
  };

  const ping = () => holdAction('ping', async () => {
    try {
      const next = await window.nexus?.pingVpn();
      if (next) setProfiles(next);
      onToast('Пинг измерен');
    } catch (error) {
      onToast(cleanError(error));
    }
  }, 2200);

  useEffect(() => {
    if (runtime.activeProfileId) return;
    if (fastest?.id) setSelectedId(fastest.id);
  }, [fastest?.id, runtime.activeProfileId]);

  useEffect(() => {
    if (!desktop || autoPing.current || !nodes.length) return;
    autoPing.current = true;
    void ping();
  }, [desktop, nodes.length]);

  useEffect(() => {
    setLatencyMs(null);
    if (!desktop || runtime.status !== 'connected' || !runtime.activeProfileId || subscriptionsOpen || diagnosticsOpen) return;
    let cancelled = false;
    let pending = false;
    const sample = async () => {
      if (pending) return;
      pending = true;
      try {
        const next = await window.nexus?.sampleVpnLatency();
        if (!cancelled && next && Number.isFinite(next.pingMs) && next.pingMs > 0) {
          setLatencyMs(Math.round(next.pingMs));
        }
      } catch {
        // A missed sample should not interrupt a working VPN or distract the user.
      } finally {
        pending = false;
      }
    };
    void sample();
    const timer = window.setInterval(() => void sample(), 3000);
    return () => {
      cancelled = true;
      window.clearInterval(timer);
    };
  }, [desktop, runtime.status, runtime.activeProfileId, subscriptionsOpen, diagnosticsOpen]);

  const powerState = runtime.status === 'connecting'
    ? 'Подключаем…'
    : runtime.status === 'error'
      ? (runtime.error || 'Ошибка подключения')
      : 'Выключено';

  if (subscriptionsOpen) return <SubscriptionManager
    subscriptions={runtime.subscriptions ?? []}
    profiles={profiles}
    action={subscriptionAction}
    onBack={() => setSubscriptionsOpen(false)}
    onAdd={addManagedSubscription}
    onRefresh={refreshManagedSubscription}
    onRefreshAll={refreshManagedSubscriptions}
    onRemove={removeManagedSubscription}
  />;

  if (diagnosticsOpen) return <ConnectionDiagnostics
    profileId={runtime.activeProfileId ?? selected?.id ?? null}
    onBack={() => setDiagnosticsOpen(false)}
    onToast={onToast}
  />;

  return <section className="page-section jey-page happ-shell">
    <div className="happ-left">
      <div className="jey-toolbar tight">
        <h2>Серверы</h2>
        <div className="jey-toolbar-actions">
          <button type="button" className="ghost-action subscription-manager-button" disabled={busy || Boolean(action)} onClick={() => setSubscriptionsOpen(true)} title="Управление подписками">
            <svg className="ico" viewBox="0 0 20 20" aria-hidden><path d="M4 5.25h12M4 10h12M4 14.75h12" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" /><circle cx="6" cy="5.25" r="1" fill="currentColor" /><circle cx="6" cy="10" r="1" fill="currentColor" /><circle cx="6" cy="14.75" r="1" fill="currentColor" /></svg>
            Подписки <span>{runtime.subscriptions?.length ?? 0}</span>
          </button>
          <button className="ghost-action" onClick={() => setImportOpen((value) => !value)} title="Добавить подписку или отдельную ссылку">
            <svg className="ico" viewBox="0 0 16 16" aria-hidden><path d="M8 3v10M3 8h10" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" /></svg>
            Добавить
          </button>
          <button className={`ghost-action ${action === 'refresh' ? 'is-spin' : ''}`} disabled={busy || Boolean(action)} onClick={() => void refresh()}>
            <svg className="ico spin-ico" viewBox="0 0 24 24" aria-hidden>
              <path fill="currentColor" d="M11.2 3.15A8.85 8.85 0 1 0 19 7.55l-1.95 1.15A6.55 6.55 0 1 1 11.2 5.45v2.7L17.45 5 11.2.65z" />
            </svg>
            Обновить
          </button>
          <button className={`ghost-action ${action === 'ping' ? 'is-rev' : ''}`} disabled={busy || Boolean(action)} onClick={() => void ping()} title="Проверить задержку всех серверов">
            <svg className="ico gauge-ico" viewBox="0 0 20 14" aria-hidden>
              <path d="M2.3 11.6a7.7 7.7 0 0 1 15.4 0" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
              <path className="gauge-needle" d="M10 11.55 5.35 6.55" fill="none" stroke="currentColor" strokeWidth="1.65" strokeLinecap="round" />
              <circle cx="10" cy="11.55" r="1.15" fill="currentColor" />
            </svg>
            Пинг
          </button>
          {!runtime.xrayReady && <button className="ghost-action core-download-action" disabled={syncing} onClick={onSync}>Скачать ядро {xrayUpdate?.latestVersion ?? ''}</button>}
        </div>
      </div>

      {importOpen && <div className="jey-import compact slide-in">
        <textarea className="jey-link" rows={2} value={link} onChange={(event) => setLink(event.target.value)} placeholder="Подписка https://… или vless:// hy2://" />
        <div className="jey-import-row">
          <input className="jey-name" value={name} onChange={(event) => setName(event.target.value)} placeholder="Имя (необязательно)" />
          <button className="primary-button small" disabled={busy || !link.trim()} onClick={() => void importLink()}>Добавить</button>
        </div>
      </div>}

      {tabs.length > 1 && <div className="jey-subs">
        {tabs.map((key) => <button key={key} className={`jey-sub ${tab === key ? 'active' : ''}`} onClick={() => setTab(key)}>
          {key === 'all'
            ? `Все · ${nodes.length}`
            : key === 'manual'
              ? `Ручные · ${nodes.filter((item) => subscriptionKey(item) === key).length}`
              : `${(runtime.subscriptions ?? []).find((item) => item.url === key)?.title || 'Подписка'} · ${nodes.filter((item) => subscriptionKey(item) === key).length}`}
        </button>)}
      </div>}

      <div className={`happ-card ${info ? 'is-subscription' : 'is-overview'}`}>
        <div className="happ-card-main">
          <span className="happ-card-symbol" aria-hidden>
            <svg viewBox="0 0 24 24"><rect x="4" y="4" width="16" height="6" rx="2" fill="none" stroke="currentColor" strokeWidth="1.45" /><rect x="4" y="14" width="16" height="6" rx="2" fill="none" stroke="currentColor" strokeWidth="1.45" /><circle cx="7.5" cy="7" r=".9" fill="currentColor" /><circle cx="7.5" cy="17" r=".9" fill="currentColor" /><path d="M11 7h5.5M11 17h5.5" fill="none" stroke="currentColor" strokeWidth="1.35" strokeLinecap="round" /></svg>
          </span>
          <div className="happ-card-copy">
            <small>{info ? 'Выбранная подписка' : 'Текущая выборка'}</small>
            <strong>{title}</strong>
            <span>{info
              ? `Обновлено ${formatWhen(info.lastSync)}`
              : tab === 'manual'
                ? 'Серверы, добавленные отдельными ссылками'
                : 'Серверы из всех доступных источников'}</span>
          </div>
        </div>
        <div className="happ-card-metrics">
          <span><small>Серверов</small><strong>{visible.length}</strong></span>
          <span><small>{info ? 'Трафик' : 'Подписок'}</small><strong>{info ? `${formatBytes(used)} / ${quota}` : runtime.subscriptions?.length ?? 0}</strong></span>
        </div>
        {info && <div className="happ-card-details">
          <span className="happ-expire">Истекает {formatExpire(info.expireAt)}</span>
          <span>{info.updateHours ? `Автообновление: каждые ${info.updateHours} ч.` : 'Интервал обновления не задан'}</span>
        </div>}
        {info?.announce && <div className="happ-ribbon">{info.announce}</div>}
      </div>

      <div className="happ-list">
        {listed.map((profile) => {
          const live = runtime.status === 'connected' && runtime.activeProfileId === profile.id;
          const picked = selected?.id === profile.id;
          const blocked = canConnect(profile);
          return <button key={profile.id} className={`happ-row ${live ? 'is-live' : ''} ${picked ? 'is-active' : ''} ${blocked ? 'is-off' : ''}`} onClick={() => setSelectedId(profile.id)} onDoubleClick={() => { if (blocked) onToast(blocked); else void connect(profile.id); }}>
            <Flag code={profile.country} />
            <span className="happ-copy">
              <strong>{displayName(profile)}</strong>
              <small>{blocked || stackOf(profile)}</small>
            </span>
            {live ? <em className="happ-on">ВКЛ</em> : <Signal ms={profile.pingMs} />}
            <span className="happ-go">›</span>
          </button>;
        })}
      </div>
    </div>

    <aside className="happ-right">
      {runtime.status === 'connected' && <span className="tunnel-session-counter" aria-label={`Время подключения ${sessionDuration}`}>{sessionDuration}</span>}
      {runtime.status === 'connected' && panelProfile && <div className="tunnel-route" aria-label={`Защищённый маршрут к серверу ${panelLocation.detail}`}>
        <span className="tunnel-route-device" title="Это устройство">
          <svg viewBox="0 0 24 24" aria-hidden><rect x="4" y="3.5" width="16" height="12" rx="2" /><path d="M8 20h8M10 15.5 9 20m5-4.5 1 4.5" /></svg>
        </span>
        <span className="tunnel-route-track" aria-hidden><i /></span>
        <span className="tunnel-route-server" title={panelLocation.detail}><Flag code={panelProfile.country} /></span>
      </div>}
      <button
        className={`power-orb ${onAir ? 'is-on' : ''} ${otherLive ? 'is-other' : ''} ${runtime.status === 'connecting' ? 'is-wait' : ''}`}
        disabled={busy}
        onClick={() => void togglePower()}
        aria-label={onAir ? 'Выключить VPN' : otherLive ? 'Переключить сервер' : 'Включить VPN'}
      >
        <span className="orb-halo orb-halo-primary" />
        <span className="orb-halo orb-halo-follow" />
        <span className="orb-halo orb-halo-wait" />
        <span className="orb-core">⏻</span>
      </button>
      <div className="power-meta">
        <strong>{panelLocation.country}</strong>
        {panelLocation.detail !== panelLocation.country && <small className="power-location">{panelLocation.detail}</small>}
        {runtime.status === 'connected'
          ? <span className="power-connected"><i />Подключено {latencyMs == null ? '· замеряем…' : <>· <b>{latencyMs} мс</b></>}</span>
          : <span className={`power-state ${runtime.status === 'error' ? 'is-error' : ''}`}>{powerState}</span>}
      </div>
      <div className="mode-switch" aria-label="Режим подключения">
        <div className="mode-switch-options">
          <button
            type="button"
            className={displayedMode === 'proxy' ? 'active' : ''}
            aria-pressed={displayedMode === 'proxy'}
            disabled={busy || runtime.status === 'connecting'}
            onClick={() => void selectConnectionMode('proxy')}
          >PROXY</button>
          <button
            type="button"
            className={displayedMode === 'tun' ? 'active' : ''}
            aria-pressed={displayedMode === 'tun'}
            disabled={busy || runtime.status === 'connecting'}
            onClick={() => void selectConnectionMode('tun')}
          >TUN</button>
        </div>
      </div>
      <button type="button" className="diagnostics-entry" onClick={() => setDiagnosticsOpen(true)}>
        <span className="diagnostics-entry-icon"><svg viewBox="0 0 24 24" aria-hidden><path d="M4 13h3l2-6 4 11 2-5h5" /><circle cx="12" cy="12" r="9" /></svg></span>
        <span><strong>Диагностика</strong><small>Ядро, процесс и порты</small></span>
        <b>→</b>
      </button>
      <div className={`auto-connect-summary ${settings.autoConnectVpn ? 'is-on' : ''}`}><i /><span>Автоподключение {settings.autoConnectVpn ? 'включено' : 'выключено'}</span></div>
      {!runtime.xrayReady && <div className="jey-note"><span>i</span><div><strong>Ставим ядро</strong><p>{xrayUpdate?.error || 'Качаем Xray / sing-box. Потом нажми большую кнопку.'}</p></div></div>}
    </aside>
  </section>;
}
