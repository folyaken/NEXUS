const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const { VpnManager } = require(path.join(root, 'dist-electron', 'vpn-manager.js'));

const manager = new VpnManager(path.join(os.tmpdir(), `nexus-mode-session-${process.pid}`));
manager.setState('connected', 'profile-a', 1234);
const firstRuntime = manager.runtime();
assert.match(firstRuntime.connectedAt, /^\d{4}-\d{2}-\d{2}T/, 'a connected runtime must publish its session start');

const continuedAt = '2026-08-14T09:10:11.000Z';
manager.setState('connected', 'profile-a', 4321, undefined, continuedAt);
assert.equal(manager.runtime().connectedAt, continuedAt, 'an automatic mode reconnect must preserve the session start');
manager.setState('disconnected', null, null);
assert.equal(manager.runtime().connectedAt, null, 'disconnect must end the session counter');
manager.setState('error', 'profile-a', null, 'test');
assert.equal(manager.runtime().connectedAt, null, 'a failed connection must not retain an active session');
manager.emitLog('info', 'retained log event');
const retainedLogs = manager.getLogs();
assert.equal(retainedLogs[0]?.message, 'retained log event', 'the log screen must receive retained VPN events on initial load');
retainedLogs[0].message = 'mutated renderer copy';
assert.equal(manager.getLogs()[0]?.message, 'retained log event', 'log history must be returned as defensive copies');

const main = fs.readFileSync(path.join(root, 'src', 'main', 'main.ts'), 'utf8');
const switchStart = main.indexOf("ipcMain.handle('vpn:switch-mode'");
const switchEnd = main.indexOf("ipcMain.handle('vpn:ensure-core'", switchStart);
assert.ok(switchStart > 0 && switchEnd > switchStart, 'main process must register the live mode switch IPC');
const switchHandler = main.slice(switchStart, switchEnd);
assert.match(switchHandler, /requestedMode !== 'proxy' && requestedMode !== 'tun'/);
assert.match(switchHandler, /await saveSettings\(\{/);
assert.match(switchHandler, /vpnMode: requestedMode/);
assert.match(switchHandler, /vpnSplitTunnel: requestedMode === 'tun'/);
assert.match(switchHandler, /current\.status !== 'connected' \|\| !current\.activeProfileId/);
assert.match(switchHandler, /current\.connectedAt/);
assert.ok(switchHandler.indexOf('await saveSettings') < switchHandler.indexOf('return vpn.connect'), 'the selected mode must be durable before reconnect');

const preload = fs.readFileSync(path.join(root, 'src', 'main', 'preload.ts'), 'utf8');
const env = fs.readFileSync(path.join(root, 'src', 'renderer', 'env.d.ts'), 'utf8');
const types = fs.readFileSync(path.join(root, 'src', 'main', 'types.ts'), 'utf8');
const app = fs.readFileSync(path.join(root, 'src', 'renderer', 'App.tsx'), 'utf8');
const page = fs.readFileSync(path.join(root, 'src', 'renderer', 'Jey2RayPage.tsx'), 'utf8');
const vpnManager = fs.readFileSync(path.join(root, 'src', 'main', 'vpn-manager.ts'), 'utf8');
const styles = fs.readFileSync(path.join(root, 'src', 'renderer', 'styles.css'), 'utf8');
const packageJson = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));

function pngDimensions(filePath) {
  const image = fs.readFileSync(filePath);
  assert.equal(image.subarray(0, 8).toString('hex'), '89504e470d0a1a0a', `${filePath} must be a PNG image`);
  return { width: image.readUInt32BE(16), height: image.readUInt32BE(20) };
}

assert.match(preload, /switchVpnMode: \(mode: 'proxy' \| 'tun'\)/);
assert.match(env, /switchVpnMode\(mode: 'proxy' \| 'tun'\): Promise<VpnRuntime>/);
assert.match(preload, /getAboutInfo: \(\): Promise<AboutSystemInfo> => ipcRenderer\.invoke\('about:get-info'\)/);
assert.match(preload, /checkNexusUpdate: \(\): Promise<NexusUpdateCheck> => ipcRenderer\.invoke\('about:check-update'\)/);
assert.match(env, /getAboutInfo\(\): Promise<AboutSystemInfo>/);
assert.match(env, /checkNexusUpdate\(\): Promise<NexusUpdateCheck>/);
assert.match(types, /export interface AboutSystemInfo/);
assert.match(types, /xrayVersion: string \| null/);
assert.match(types, /singBoxVersion: string \| null/);
assert.match(types, /export interface NexusUpdateCheck/);
assert.match(types, /status: 'placeholder'/);
assert.match(types, /connectedAt: string \| null/);
assert.match(types, /language: 'ru'/);
assert.match(types, /theme: 'dark'/);
assert.match(types, /appearance: 'indigo' \| 'graphite'/);
assert.match(main, /appearance: raw\.appearance === 'graphite' \? 'graphite' : 'indigo'/);
assert.match(page, /const selectConnectionMode = async/);
assert.match(page, /await window\.nexus\?\.switchVpnMode\(next\)/);
assert.match(page, /disabled=\{busy \|\| runtime\.status === 'connecting'\}/, 'connected VPN must not disable the PROXY/TUN buttons');
assert.match(page, /setInterval\(\(\) => setSessionNow\(Date\.now\(\)\), 1000\)/);
assert.match(page, /<span className="tunnel-session-counter"[^>]*>\{sessionDuration\}<\/span>/);
assert.ok(page.indexOf('className="tunnel-session-counter"') < page.indexOf('className="tunnel-route"'), 'the session timer must be above the animated route');
assert.match(page, /formatSessionDuration\(runtime\.connectedAt, sessionNow\)/);
assert.doesNotMatch(page, /<PingSparkline|className="tunnel-ping"|className="power-session"|<small>Сессия<\/small>/);
assert.match(page, /orb-halo orb-halo-primary/);
assert.match(page, /orb-halo orb-halo-follow/);
assert.match(page, /orb-halo orb-halo-wait/);
assert.match(page, /if \(settingsOpen\) return <section className="page-section jey-page app-settings-page">/);
assert.match(page, /settings-gear-button/);
assert.match(page, /Открыть настройки Jey2Ray/);
assert.match(page, /const \[settingsTab, setSettingsTab\] = useState<'general' \| 'applications'>\('general'\)/);
assert.match(page, /role="tablist" aria-label="Разделы настроек Jey2Ray"/);
assert.match(page, /id="jey-settings-panel"[\s\S]*role="tabpanel"[\s\S]*aria-labelledby=\{`jey-settings-\$\{settingsTab\}-tab`\}/);
assert.match(page, /role="tab"[\s\S]*aria-selected=\{settingsTab === 'general'\}[\s\S]*>Общие</);
assert.match(page, /role="tab"[\s\S]*aria-selected=\{settingsTab === 'applications'\}[\s\S]*>Настройка приложений</);
assert.match(page, /settingsTab === 'general' \? <section className="app-settings-card auto-settings-card">/);
assert.ok(page.indexOf("settingsTab === 'general' ? <section") < page.indexOf('routing-settings-card'), 'application routing must be rendered only in the applications tab branch');
assert.match(page, /window\.nexus\?\.pickVpnApps\(\)/);
assert.match(page, /role="radiogroup" aria-label="Режим маршрутизации приложений"/);
assert.match(page, /Сначала отключи VPN, затем измени маршрутизацию приложений/);
assert.doesNotMatch(page, /autoPing/, 'opening Jey2Ray must not trigger an automatic all-server ping');
assert.equal((page.match(/void ping\(\)/g) ?? []).length, 1, 'the explicit manual ping action must remain available');
assert.match(page, /sampleVpnLatency/);

assert.doesNotMatch(app, /SettingsTab|settings-tabs|function ApplicationSettings|Настройки приложений/, 'VPN settings must not leak into global NEXUS settings');
assert.match(app, /Глобальные параметры языка, оформления и поведения NEXUS/);
assert.match(app, /Язык интерфейса/);
assert.match(app, /Тема/);
assert.match(app, /Оформление/);
assert.match(app, /appearance-options/);
assert.match(app, /if \(name === 'settings'\) return <GearIcon \/>/);
assert.match(app, /nexus-sidebar-collapsed/);
assert.match(app, /aria-label=\{sidebarCollapsed \? 'Развернуть боковую панель' : 'Свернуть боковую панель'\}/);
assert.match(app, />О программе<\/span>/);
assert.match(app, /<h1>О программе<\/h1>/);
assert.match(app, /<span>Логи<\/span>/);
assert.match(app, /<h1>Логи<\/h1>/);
assert.match(app, /role="tablist" aria-label="Источники логов"/);
assert.match(app, /Основной лог/);
assert.match(app, /Лог туннеля/);
assert.match(app, /log-console-line/);
assert.match(app, /profile-chevron/);
assert.doesNotMatch(app, />⌄<\/b>/, 'the profile menu must use the animated SVG chevron');
assert.match(main, /vpn\.getLogs\(\)/, 'the initial log list must include retained Jey2Ray events');
assert.match(vpnManager, /getLogs\(\): ModuleLog\[\]/);

assert.match(styles, /\.tunnel-session-counter \{[^}]*font-family: var\(--font-body\)/);
assert.match(styles, /\.mode-switch button \{[^}]*font-family: var\(--font-body\)[^}]*text-transform: uppercase/);
assert.match(styles, /\.power-orb\.is-on \.orb-halo-primary \{ animation: orb-wave-primary/);
assert.match(styles, /\.power-orb\.is-on \.orb-halo-follow \{ animation: orb-wave-follow/);
assert.match(styles, /\.power-orb\.is-wait \.orb-halo-wait \{ animation: orb-wave-wait/);
assert.match(styles, /100% \{ transform: scale\(1\.82\); opacity: 0; \}/);
assert.match(styles, /\.global-settings-hero \{/);
assert.match(styles, /\.app-settings-tabs \{[^}]*grid-template-columns: repeat\(2/);
assert.match(styles, /\.app-settings-tab\.is-active \{/);
assert.match(styles, /\.app-settings-page \.app-settings-card-head h3 \{ font-size: 18px/);
assert.match(styles, /\.appearance-graphite \{[\s\S]*--bg: #07090c/);
for (const graphiteArea of ['.sidebar', '.hero', '.module-card-inner', '.jey-hero', '.app-settings-tabs', '.subscription-card', '.diagnostics-report-card']) {
  assert.ok(styles.includes(`.appearance-graphite ${graphiteArea}`), `Graphite appearance must restyle ${graphiteArea}`);
}
assert.match(styles, /\.appearance-graphite \.app-settings-tab\.is-active \{[^}]*rgba\(220,224,229/);
assert.match(styles, /\.appearance-graphite \.primary-button \{[^}]*#e2e5e9/);
assert.match(styles, /\.app-shell\.is-sidebar-collapsed \.sidebar \{[^}]*flex-basis: 82px/);
assert.match(styles, /\.profile-chevron \{[^}]*transition:/);
assert.match(styles, /\.log-source-tabs \{[^}]*grid-template-columns: repeat\(6/);
assert.match(styles, /\.appearance-graphite \.happ-flag-svg \{ filter: saturate\(\.66\) brightness\(\.91\); \}/, 'Graphite flags must retain restrained colour');
assert.match(styles, /\.appearance-graphite \.app-shell \{ filter: none; \}/);
assert.doesNotMatch(styles, /\.appearance-graphite \.app-shell \{ filter: grayscale\(1\) saturate\(0\); \}/, 'Graphite must not globally desaturate flags and semantic states');
assert.doesNotMatch(styles, /\.settings-tab\.active \{|\.tunnel-ping|\.power-session/);

assert.match(main, /function coreVersion\(executable: string, product: 'xray' \| 'sing-box'\)/);
assert.match(main, /execFile\(executable, \['version'\]/);
assert.match(main, /timeout: 2_500/);
assert.match(main, /maxBuffer: 64 \* 1024/);
assert.match(main, /coreVersion\(vpn\.xrayPath\(\), 'xray'\)/);
assert.match(main, /coreVersion\(vpn\.singboxPath\(\), 'sing-box'\)/);
assert.match(main, /ipcMain\.handle\('about:get-info', \(\) => aboutSystemInfo\(\)\)/);
assert.match(main, /ipcMain\.handle\('about:check-update', \(\) => checkNexusUpdate\(\)\)/);
assert.match(app, /Версия Xray Core/);
assert.match(app, /Версия sing-box/);
assert.match(app, /Компьютер \/ ОС/);
assert.match(app, /ВРЕМЕННЫЙ КАНАЛ/);
assert.match(app, /className="about-install-button" disabled/);

assert.match(main, /const TRAY_FRAME_FILES = \{[\s\S]*disconnected:[\s\S]*connecting:[\s\S]*connected:/, 'tray branding must expose three visual VPN states');
assert.match(main, /function stopTrayAnimation\(\): void/);
assert.match(main, /if \(trayAnimation\) clearInterval\(trayAnimation\)/);
assert.match(main, /visualState === 'connecting' \? 150 : 420/);
assert.match(main, /trayAnimation\.unref\(\)/, 'tray animation must not keep the process alive');
assert.match(main, /setTrayVpnStatus\(snapshot\.runtime\.status\)/, 'VPN state events must immediately update the tray');
assert.match(main, /stopTrayAnimation\(\);[\s\S]*tray\?\.destroy\(\)/, 'quitting must release the tray timer before destroying the tray');
assert.match(main, /icon: assetPath\('nexus-app\.png'\)/);
assert.match(app, /function NexusMark\(\)[\s\S]*nexus-infinity-mark/);
assert.match(app, /function NexusShowcaseMark\(\)/);
assert.match(app, /<div className="about-mark"><NexusShowcaseMark \/><\/div>/);
assert.match(styles, /\.nexus-infinity-mark \.nexus-ribbon/);
assert.match(styles, /\.nexus-showcase-mark \{ animation: showcase-hover/);

const resourceFilters = packageJson.build.extraResources.flatMap((entry) => entry.filter ?? []);
for (const resource of ['nexus-tray.png', 'nexus-app.png', 'nexus.ico', 'tray/**/*']) {
  assert.ok(resourceFilters.includes(resource), `${resource} must be copied outside ASAR for native window and tray use`);
}
const trayAssets = [
  'nexus-off.png',
  ...Array.from({ length: 8 }, (_, index) => `nexus-connecting-${index}.png`),
  ...Array.from({ length: 6 }, (_, index) => `nexus-connected-${index}.png`),
];
for (const asset of trayAssets) {
  assert.deepEqual(pngDimensions(path.join(root, 'assets', 'tray', asset)), { width: 32, height: 32 }, `${asset} must stay sharp at Windows tray density`);
}
assert.deepEqual(pngDimensions(path.join(root, 'assets', 'nexus-tray.png')), { width: 32, height: 32 });
assert.deepEqual(pngDimensions(path.join(root, 'assets', 'nexus-app.png')), { width: 256, height: 256 });
const icoHeader = fs.readFileSync(path.join(root, 'assets', 'nexus.ico')).subarray(0, 4).toString('hex');
assert.equal(icoHeader, '00000100', 'the Windows build icon must remain a valid ICO container');

console.log('Live VPN mode, About diagnostics/update placeholder, restrained Graphite colours and stateful tray regression checks passed.');
