import { singboxProcessNames, singboxProcessPaths } from './split-tunnel';
import type { VpnLinkParams, VpnSplitApp } from './types';

export function buildSingboxConfig(
  params: VpnLinkParams,
  inboundPort: number,
  mode: 'proxy' | 'tun' = 'proxy',
  splitApps: VpnSplitApp[] = [],
): Record<string, unknown> {
  const inbounds: Record<string, unknown>[] = [
    { type: 'socks', tag: 'socks-in', listen: '127.0.0.1', listen_port: inboundPort },
    { type: 'http', tag: 'http-in', listen: '127.0.0.1', listen_port: inboundPort + 1 },
  ];
  if (mode === 'tun') {
    inbounds.push({
      type: 'tun',
      tag: 'tun-in',
      interface_name: 'nexus-tun',
      address: ['172.19.0.1/30', 'fdfe:dcba:9876::1/126'],
      mtu: 1500,
      auto_route: true,
      strict_route: false,
      stack: 'mixed',
    });
  }

  const processNames = mode === 'tun' ? singboxProcessNames(splitApps) : [];
  const processPaths = mode === 'tun' ? singboxProcessPaths(splitApps) : [];
  const splitRules: Record<string, unknown>[] = processNames.length ? [
    { inbound: ['tun-in'], process_name: processNames, action: 'route', outbound: 'proxy' },
    { inbound: ['tun-in'], process_path: processPaths, action: 'route', outbound: 'proxy' },
    { inbound: ['tun-in'], action: 'route', outbound: 'direct' },
  ] : [];

  return {
    log: { level: 'warn' },
    inbounds,
    outbounds: [{
      type: 'hysteria2',
      tag: 'proxy',
      server: params.address,
      server_port: params.port,
      password: params.password || params.uuid || '',
      tls: {
        enabled: true,
        server_name: params.sni || params.address,
        insecure: Boolean(params.allowInsecure),
      },
      ...(params.obfs ? { obfs: { type: 'salamander', password: params.obfs } } : {}),
    }, {
      type: 'direct',
      tag: 'direct',
    }],
    route: {
      auto_detect_interface: true,
      rules: splitRules,
      final: 'proxy',
    },
  };
}
