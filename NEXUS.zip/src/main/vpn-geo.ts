import { existsSync } from 'node:fs';
import { promises as fs } from 'node:fs';
import { countryByCode, looksLikeIp } from './vpn-classify';
import type { VpnProfile } from './types';

type GeoHit = { code: string; name: string; flag: string; city?: string; isp?: string };

export async function applyGeo(profiles: VpnProfile[], cacheFile: string): Promise<VpnProfile[]> {
  const cache = await loadCache(cacheFile);
  const missing = [...new Set(profiles.map((item) => item.server).filter((host) => looksLikeIp(host) && !cache[host]))];
  if (missing.length) {
    for (let index = 0; index < missing.length; index += 100) {
      const chunk = missing.slice(index, index + 100);
      try {
        const response = await fetch('http://ip-api.com/batch?fields=status,query,country,countryCode,city,isp', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(chunk),
        });
        if (!response.ok) continue;
        const rows = await response.json() as Array<{ status: string; query: string; countryCode?: string; city?: string; isp?: string }>;
        for (const row of rows) {
          if (row.status !== 'success' || !row.countryCode) continue;
          const known = countryByCode(row.countryCode);
          if (!known) continue;
          cache[row.query] = { ...known, city: row.city, isp: row.isp };
        }
      } catch {
        /* offline: keep name heuristics */
      }
    }
    await fs.writeFile(cacheFile, `${JSON.stringify(cache)}\n`, 'utf8');
  }

  return profiles.map((profile) => {
    const hit = cache[profile.server];
    if (!hit) return profile;
    const nameless = looksLikeIp(profile.name) || profile.name === profile.server || /^[a-z]{3}\d{1,2}/i.test(profile.name);
    return {
      ...profile,
      country: hit.code,
      countryName: hit.name,
      flag: hit.flag,
      name: nameless ? (hit.city ? `${hit.name} · ${hit.city}` : hit.name) : profile.name,
    };
  });
}

async function loadCache(file: string): Promise<Record<string, GeoHit>> {
  try {
    if (!existsSync(file)) return {};
    return JSON.parse(await fs.readFile(file, 'utf8')) as Record<string, GeoHit>;
  } catch {
    return {};
  }
}
